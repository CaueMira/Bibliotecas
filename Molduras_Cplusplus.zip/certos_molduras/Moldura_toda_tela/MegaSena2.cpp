#include <windows.h>
#include<iostream>
#include<iomanip>
#include<stdlib.h>
#include<cstdlib>
#include<ctime>



using namespace std;


  
//fun��o para fazer funcionar o gotoxy
void gotoxy(int x, int y)
{
HANDLE hOut;
COORD Position;
hOut = GetStdHandle(STD_OUTPUT_HANDLE);
Position.X = x;
Position.Y = y;
SetConsoleCursorPosition(hOut,Position);
}
//=========================================================
//fun��o para cor:
enum DOS_COLORS {
        BLACK, BLUE, GREEN, CYAN, RED, MAGENTA, BROWN,
        LIGHT_GRAY, DARK_GRAY, LIGHT_BLUE, LIGHT_GREEN, LIGHT_CYAN,
        LIGHT_RED, LIGHT_MAGENTA, YELLOW, WHITE };
//===========================================================
void textcolor (DOS_COLORS iColor)
{
        HANDLE hl = GetStdHandle(STD_OUTPUT_HANDLE);
        CONSOLE_SCREEN_BUFFER_INFO bufferInfo;
        BOOL b = GetConsoleScreenBufferInfo(hl, &bufferInfo);
        bufferInfo.wAttributes &= 0x00F0;
        SetConsoleTextAttribute (hl, bufferInfo.wAttributes |= iColor);
}
//=========================================================
int sena[6][10], i, j, r, s, lin, col, maior, TOT, escolha[15]; 
bool bol;
main()
{


	setlocale(LC_ALL, "Portuguese"); //Definindo linguagem padr�o para portugu�s
	//Definindo cursor na primeira matriz.
    lin=5;  // posiciona o cursor na  linha indicados no gotoxy
    gotoxy(32,2); // posiciona o cursor na  coluna e linha indicados no gotoxy
    textcolor(LIGHT_GREEN); //definindo cor verde
    cout<<" Mega-Sena ";
    gotoxy(10,3); // posicionando novamente o cursor.
    cout<<"VOC� PODE JOGAR MARCANDO EM UM OU NOS DOIS QUADROS ABAIXO:";
	
    //leitura da Primeira Tabela:
    textcolor(LIGHT_RED); //definindo cor vermelha
    for(i=0;i<6;i++)  // leitura da linha da matriz         
	{ col=10; // posiciona o cursor na coluna desejada
        for (j=0;j<10;j++) // leitura da coluna da matriz
        {
        	r+=1;
        	gotoxy(col,lin);  // para posicionar o cursor para ler o elemento da matriz
        	cout<<"["<<r<<"]";	
	        col=col+6; // d� 6 espa�os entre cada elemento da matriz
	    } 
    lin=lin+1; //pular uma linha
    }
    textcolor(YELLOW); 
    gotoxy(10,11); //reposicionando cursor
    cout<<"Defina quantos n�meros deseja jogar [6] � [15]: ";
	cin>>TOT;
	gotoxy(10,12);
	col = 80;
	lin = 5; 
    for (i=0;i<TOT;i++)
    { 
    	gotoxy(col,lin);
    	cout<<"Escolha os n�meros: ";
    	cin>>escolha[i];
    	if (TOT>6)
    	{
    		gotoxy(100,5);
		}
    	lin+=1;
	}
    cout<<"Para anular este jogo, marque ao lado:                [  ]";
    r=0;

	
	//Segunda Tabela:
	gotoxy(10,20);
	textcolor(LIGHT_RED); //definindo cor vermelha
	lin=lin+3;
    for(i=0;i<6;i++)  // leitura da linha da matriz         
	{ col=10; // posiciona o cursor na coluna desejada
        for (j=0;j<10;j++) // leitura da coluna da matriz
        {
        	r+=1;
        	gotoxy(col,lin);  // para posicionar o cursor para ler o elemento da matriz
        	cout<<"["<<r<<"]";		
	        col=col+6; // d� 6 espa�os entre cada elemento da matriz
	    } 
    lin=lin+1; //pular uma linha
    }
    gotoxy(10,20); //posicionando o cursor
    textcolor(YELLOW);
    cout<<"Para anular este jogo, marque ao lado:                [  ]";
    gotoxy(10,24); //posicionando o cursor
    cout<<"Assinale quantos n�meros voc� est� marcando neste jogo:";
    r=5; //definindo valor da jogada.
    gotoxy(10,25); //posicionando o cursor
    textcolor(LIGHT_RED);
    for(i=0; i<10;i++) //leitura dos valores na linha.
    {
    	r+=1;
    	cout<<"["<<r<<"]  ";
	}
	
	//Definindo a SURPRESINHA:
	textcolor(YELLOW);
    gotoxy(10,27); //apontando cursor
    cout<<"SURPRESINHA - Aqui o sistema escolhe os n�meros por voc�.";
    gotoxy(24,28);
    cout<<"Indique quantas apostas deseja fazer:";
    r=0; //zerando contador
    gotoxy(10,29);
    textcolor(LIGHT_RED);
    for(i=0; i<8;i++) //leitura dos valores na linha.
    {
    	r+=1;
    	cout<<"[ "<<r<<" ]  ";
	}
	
	//Defininto TEIMOSINHA:
	textcolor(YELLOW);
	gotoxy(10,31);
    cout<<"TEIMOSINHA - Escolha em quantos concursos voc� quer";
    gotoxy(23,32);
    cout<<"participar com este mesmo jogo:";
    r=2; //gambi
    gotoxy(10,33);
    textcolor(LIGHT_RED);
    for(i=0; i<8;i+=2) //leitura dos valores na linha.
    {
    	r=r+i;//gambi nervosa
    	if (r<=8) //gambi nervosissima
    	{
    		cout<<"   [ "<<r<<" ]             ";
		}

	}
	
	//Definindo o BOL�O:
	textcolor(YELLOW);
	gotoxy(10,35);
    cout<<"BOL�O - Aqui voc� faz o seu bol�o de at� 100 cotas.";
    gotoxy(23,36);
    cout<<"Assinale abaixo o n�mero de cotas:";
    r=0; //zerando contador
    gotoxy(10,37);
    textcolor(LIGHT_RED);
    for(i=0; i<9;i++) //leitura dos valores na linha.
    {
    	r+=1;
		cout<<"["<<r<<"]  ";
	}
	cout<<"     Dezena.";
	gotoxy(10,38);
	r=0; //zerando contador
    for(i=0; i<10;i++) //leitura dos valores na linha.
    {
		cout<<"["<<r<<"]  ";
		r+=1;
	}
	cout<<"Unidade.";
	gotoxy(10,39);
	cout<<"[100] Cota Limite.";
	textcolor(LIGHT_GREEN);
	gotoxy(10,41);
	cout<<"CONFIRA O BILHETE IMPRESSO PELO TERMINAL.";
	gotoxy(10,42);
	cout<<"ELE � O �NICO COMPROVANTE DA APOSTA.";
	gotoxy(32,44);
	textcolor(LIGHT_BLUE);
	cout<<" LOTERIAS CLAWER!  ";
	gotoxy(10,45);
	cout<<"Preencha toda a �rea dos n�meros escolhidos com caneta esfe-";
	gotoxy(10,47);
	cout<<"rogr�fica azul ou preta.";
	gotoxy(50,5);
	cout<<"Vamos definir sua jogada: ";
	cout<<"\n\n\n\n\n";
	
}
    

