#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <windows.h>
#include <iostream>
#include "cores.h"
#define TRUE 1
using namespace std;

int resp, opc;
int i = 0;





int insere ( char ins_nome [ 100 ] );
void imprime ( );
void inserindo ( );
void Mostra ( );
void Excluindo ( );
void Elementos ( );
int exclui ( char ins_nome [ 100 ] );




void Janela ( ) {
     int c, l;
     for ( c = 3; c <= 78 ; c++ ) {
         gotoxy ( c , 1 );
         printf ( "%c" , 205 );
         gotoxy ( c , 4 );
         printf ( "%c" , 205 );
     }
     gotoxy ( 2 , 1 );
     printf ( "%c" , 201 );
     gotoxy ( 79 , 1 );
     printf ( "%c" , 187 );
     gotoxy ( 79 , 4 );
     printf ( "%c" , 188 );
     gotoxy ( 2 , 4 );
     printf ( "%c" , 200 );
     for ( l = 2; l <= 3 ; l++ ) {
         gotoxy ( 2 , l );
         printf ( "%c" , 186 );
         gotoxy ( 79 , l );
         printf ( "%c" , 186 );
     }
     for ( c = 3; c <= 78 ; c++ ) {
         for ( l = 2; l <= 3 ; l++ ) {
              gotoxy ( c , l );
              printf ( "%c" , 177 );
         }
     }
     for ( c = 3; c <= 78 ; c++ ) {
         gotoxy ( c , 5 );
         printf ( "%c" , 205 );
         gotoxy ( c , 25 );
         printf ( "%c" , 205 );
     }
     gotoxy ( 2 , 5 );
     printf ( "%c" , 201 );
     gotoxy ( 79 , 5 );
     printf ( "%c" , 187 );
     gotoxy ( 79 , 25 );
     printf ( "%c" , 188 );
     gotoxy ( 2 , 25 );
     printf ( "%c" , 200 );
     gotoxy ( 2 , 8 );
     printf ( "%c" , 204 );
     gotoxy ( 79 , 8 );
     printf ( "%c" , 185 );
     for ( l = 9; l <= 24 ; l++ ) {
         gotoxy ( 2 , l );
         printf ( "%c" , 186 );
         gotoxy ( 79 , l );
         printf ( "%c" , 186 );
     }
     for ( l = 6; l <= 7 ; l++ ) {
         gotoxy ( 2 , l );
         printf ( "%c" , 186 );
         gotoxy ( 79 , l );
         printf ( "%c" , 186 );
     }
     for ( c = 3; c <= 78 ; c++ ) {
         gotoxy ( c , 8 );
         printf ( "%c" , 205 );
     }
     for ( c = 5; c <= 25 ; c++ ) {
         gotoxy ( c + 25 , 9 );
         printf ( "%c" , 205 );
         gotoxy ( c + 25 , 24 );
         printf ( "%c" , 205 );
     }
     gotoxy ( 29 , 9 );
     printf ( "%c" , 201 );
     gotoxy ( 51 , 9 );
     printf ( "%c" , 187 );
     gotoxy ( 51 , 24 );
     printf ( "%c" , 188 );
     gotoxy ( 29 , 24 );
     printf ( "%c" , 200 );
     for ( l = 10; l <= 23 ; l++ ) {
         gotoxy ( 29 , l );
         printf ( "%c" , 186 );
         gotoxy ( 51 , l );
         printf ( "%c" , 186 );
     }
}
int main ( ) {
     system ( "title PROGRAMA EXEMPLO DE MENU" );
     do {
         system ( "cls" );
         Janela ( );
         textcolor (LIGHT_CYAN);
         gotoxy ( 30 , 3 );
         cout<< "PROGRAMA CADASTRO DE ALUNOS" ;
         textcolor (LIGHT_BLUE);
         gotoxy ( 30 , 7 );
         printf ( "ESCOLHA UMA OPCAO ABAIXO" );
         textcolor ( YELLOW );
         gotoxy ( 35 , 11 );
         printf ( "1 - INSERIR" );
         gotoxy ( 35 , 13 );
         printf ( "2 - LISTAR" );
         gotoxy ( 35 , 15 );
         printf ( "3 - EXCLUIR" );
         gotoxy ( 35 , 17 );
         printf ( "4 - ELEMENTOS" );
         gotoxy ( 35 , 19 );
         printf ( "5 - SAIR" );
         gotoxy ( 35 , 21 );
         textcolor ( LIGHT_RED );
         scanf ( "%d" , &opc );
         fflush ( stdin );
         if ( opc == 1 ) {
              system ( "cls" );
              inserindo ( );
         }
         if ( opc == 2 ) {
              Mostra ( );
         }
         if ( opc == 3 ) {
              Excluindo ( );
         }
         if ( opc == 4 ) {
              Elementos ( );
         }
         if ( opc == 5 ) {
              textcolor ( LIGHT_RED );
              gotoxy ( 34 , 21 );
              printf ( " AGRADECEMOS A PREFERENCIA" );
              Sleep ( 1800 );
              exit ( 0 );
         } else {
              textcolor ( LIGHT_RED );
              gotoxy ( 34 , 21 );
              printf ( "\a OPCAO ERRADA" );
              Sleep ( 800 );
         }
     } while ( 1 );
}
void inserindo ( ) {
     textcolor ( LIGHT_RED );
     gotoxy ( 30 , 3 );
     printf ( "PROGRAMA LISTA ENCADEADA" );
     textcolor ( LIGHT_BLUE );
     gotoxy ( 30 , 5 );
     printf ( "INSERINDO ITENS" );
     textcolor ( LIGHT_GREEN );
     gotoxy ( 30 , 7 );
     printf ( "NOME DO ITEM A SER INSERIDO: " );
     textcolor ( LIGHT_RED );
    
   
     if ( resp == TRUE ) {
         textcolor ( LIGHT_CYAN );
         gotoxy ( 30 , 9 );
         printf ( "ITEM INSERIDO COM SUCESSO" );
         i++;
     }
     getche ( );
     main ( );
}
void Mostra ( ) {
     system ( "cls" );
     textcolor ( LIGHT_RED );
     gotoxy ( 30 , 3 );
     printf ( "PROGRAMA LISTA ENCADEADA" );
     textcolor ( LIGHT_BLUE );
     gotoxy ( 30 , 5 );
     printf ( "ELEMENTOS DA LISTA" );
     printf ( "\n\n\t\t" );
     imprime ( );
     getche ( );
     main ( );
}
void Excluindo ( ) {
     system ( "cls" );
     do {
         textcolor ( LIGHT_RED );
         gotoxy ( 30 , 3 );
         printf ( "PROGRAMA LISTA ENCADEADA" );
         textcolor ( LIGHT_BLUE );
         gotoxy ( 30 , 5 );
         printf ( "ELEMENTOS DA LISTA" );
         printf ( "\n\n\t\t" );
         imprime ( );
         textcolor ( LIGHT_CYAN );
         gotoxy ( 30 , 17 );
         printf ( "ESCOLHA UM PARA SER EXCLUIDO" );
         gotoxy ( 30 , 19 );
         textcolor ( LIGHT_RED );
        
         getche ( );
         system ( "cls" );
     } while ( 1 );
}
void Elementos ( ) {
     system ( "cls" );
     textcolor ( LIGHT_RED );
     gotoxy ( 30 , 3 );
     printf ( "PROGRAMA LISTA ENCADEADA" );
     textcolor ( LIGHT_BLUE );
     gotoxy ( 30 , 5 );
     printf ( "ELEMENTOS DA LISTA" );
     printf ( "\n\n\t\t" );
     imprime ( );
     textcolor ( LIGHT_CYAN );
     gotoxy ( 30 , 17 );
     printf ( "QUANTIDADE DE ELEMENTOS" );
     textcolor ( YELLOW );
     gotoxy ( 30 , 19 );
     printf ( "%d ELEMENTOS" , i );
     getche ( );
     main ( );
}

int insere ( char Nome_Palavra [ 100 ] ) {
     gotoxy ( 30 , 17 );
     printf ( "INSERINDO ELEMENTOS INCOMPLETO " );
     
     return ( 1 );
}
void imprime ( ) {
     
     }

int exclui ( char stringnome [ 100 ] ) {
     
               printf ( "EXCLUINDO ELEMENTOS INCOMPLETO " );
         
         return ( 1 );
     }

