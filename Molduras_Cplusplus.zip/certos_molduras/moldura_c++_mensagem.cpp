
#include <iostream>
#include <stdlib.h>


using namespace std;
     

void funcMens (char a[])
{
    int largura = 75, interna, i, cont = 0;
       
    while (a[cont] != '\0')
    {
        cont++;
    }
    
    largura = largura - cont;
    
    if (largura % 2 != 0) //Largura par
    {
    largura--;
    }

    interna = largura + cont + 2;
    system ("cls");
    cout<<"\n\n";
    cout<<"\n\xC9"; //Canto superior esquerdo
    
    for (i = 1; i <= interna; i++)
    {
    cout<<"\xCD";//Linha horizontal
    }
    
    cout<<"\xBB"; //Canto superior direito
    
    cout<<"\n\xBA"; //Linha vertical
    
    for (i = 1; i <= interna; i++)
    {
    cout<<" ";
    }        
                                   
    cout<<"\xBA"; //Linha vertical
    
    cout<<"\n\xBA"; //Linha vertical
    
    for (i = 1; i <= largura / 2; i++)
    {
    cout<<"*";
    }
    
    cout<<" "<<a<<" ";
    
                            
    for (i = 1; i <= largura  / 2; i++)
    {
    cout<<"*";
    }
    
    cout<<"\xBA"; //Linha vertical
    
    cout<<"\n\xBA"; //Linha vertical
    
    for (i = 1; i <= interna; i++)
    {
    cout<<" ";
    }           
                                                                       
    cout<<"\xBA"; //Linha vertical
    cout<<"\n\xC8"; //Canto inferior esquerdo
    for (i = 1; i <= interna; i++)
    {
    cout<<"\xCD"; //Linha horizontal
    }
    
    cout<<"\xBC"; //Canto inferior esquerdo
    cout<<"\n\n";      
}

int main ()
{
    char mensagem[76];
    cout<<"Digite uma mensagem:\n\n";
    gets(mensagem);
    funcMens(mensagem);
    cout<<"\n\n";
    system("pause");
    return 0;
}

