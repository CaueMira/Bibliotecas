
// 163 �
//130  �
// 198 �
// 135 �
// 160 �

#include <iostream>
#include <stdlib.h>
#include "cores.h"

using namespace std;
     

void moldura (int lin_ini,int col_ini,int lin_fim,int col_fim)
{
    textcolor(LIGHT_BLUE);
  // Inicializando os cantos da tela
    gotoxy(col_ini,lin_ini);
    cout<<"\n\xC9"; //Canto superior esquerdo
 
    gotoxy(col_fim,lin_ini+1);
    cout<<"\xBB"; //Canto superior direito

    gotoxy(col_ini,lin_fim);  
    cout<<"\n\xC8"; //Canto inferior esquerdo

    gotoxy(col_fim,lin_fim+1);  
    cout<<"\xBC"; //Canto inferior esquerdo  
    
   // Linha Horizontal - Primeira


    for (int i = col_ini-1; i < col_fim; i++)
    {
       gotoxy(i,lin_ini+1); // Linha Superior	  
       cout<<"\xCD";//Linha horizontal
       gotoxy(i,lin_fim+1); // Linha Inferior	  
       cout<<"\xCD";//Linha horizontal
    }
   

   for ( int i = lin_ini+2; i <= lin_fim; i++)
    {
       gotoxy(col_ini-2,i); // Linha Direita	  
       cout<<"\xBA"; //Linha vertical Direita
       gotoxy(col_fim,i); // Linha Esquerda	  
       cout<<"\xBA"; //Linha vertical Esquerda
    }
 
   
      
}

main ()
{
    int col_ini,col_fim,lin_ini,lin_fim;
  //  setlocale(LC_ALL, "Portuguese"); se usar muda o valor do caracter hexadecimal
    moldura(2,2,25,45);
    gotoxy(10, 8);
    textcolor(YELLOW);
    cout<<" C++ :: muito legal !!!";
    textcolor(LIGHT_MAGENTA);
    gotoxy(5, 12);
    cout<<" Para escrever aqui...use o gotoxy !!!";
    gotoxy(2,27);
    system("pause");

}

