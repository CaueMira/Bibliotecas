
// 163 �
//130  �
// 198 �
// 135 �
// 160 �

#include <iostream>
#include <stdlib.h>
#include "cores.h"

using namespace std;
     

void funcMens (char a[])
{
    int largura = 75, interna, i, cont = 0;
    
   

	textcolor(LIGHT_BLUE);
    
	   
    while (a[cont] != '\0')
    {
        cont++;
    }
    
    largura = largura - cont;
    
    if (largura % 2 != 0) //Largura par
    {
    largura--;
    }

    interna = largura + cont + 2;
    system ("cls");
    cout<<"\n\n";
    cout<<"\n\xC9"; //Canto superior esquerdo
    
    for (i = 1; i <= interna; i++)
    {
    	textcolor(LIGHT_BLUE);
    cout<<"\xCD";//Linha horizontal
    }
   textcolor(LIGHT_BLUE); 
    cout<<"\xBB"; //Canto superior direito
   textcolor(LIGHT_BLUE); 
    cout<<"\n\xBA"; //Linha vertical
    
    for (i = 1; i <= interna; i++)
    {
    cout<<" ";
    }        
                                   
    textcolor(LIGHT_BLUE);
	cout<<"\xBA"; //Linha vertical
    textcolor(LIGHT_BLUE);
    cout<<"\n\xBA"; //Linha vertical
    
    for (i = 1; i <= largura / 2; i++)
    {
    	 textcolor(YELLOW);
    cout<<"*";
    }
    textcolor(GREEN);
    cout<<" "<<a<<" ";
    
                            
    for (i = 1; i <= largura  / 2; i++)
    {
    	textcolor(YELLOW);
    cout<<"*";
    }
    textcolor(LIGHT_BLUE);
    cout<<"\xBA"; //Linha vertical
    textcolor(LIGHT_BLUE);
    cout<<"\n\xBA"; //Linha vertical
    
    for (i = 1; i <= interna; i++)
    {
    cout<<" ";
    }           
     textcolor(LIGHT_BLUE);                                                                  
    cout<<"\xBA"; //Linha vertical
    cout<<"\n\xC8"; //Canto inferior esquerdo
    for (i = 1; i <= interna; i++)
    {
    cout<<"\xCD"; //Linha horizontal
    }
    
    cout<<"\xBC"; //Canto inferior esquerdo
    cout<<"\n\n";      
}

int main ()
{
    char mensagem[76];
    cout<<"Digite uma mensagem:\n\n";
    gets(mensagem);
    funcMens(mensagem);
    textcolor(WHITE);
    cout<<"\n\n\n\n\n";
    system("pause");
    return 0;
}

